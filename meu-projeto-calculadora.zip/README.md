# 🧮 Calculadora Simples

Este é um projeto bem simples em **HTML, CSS e JavaScript** para somar dois números.

## 🚀 Como usar
1. Baixe/clonar este repositório:
   ```bash
   git clone https://github.com/seu-usuario/meu-projeto-calculadora.git
   ```
2. Abra o arquivo `index.html` no navegador.
3. Digite dois números e clique em **Calcular**.

## 📂 Estrutura do projeto
```
meu-projeto-calculadora/
│── index.html    # Página principal
│── funcao.js     # Função de soma
│── script.js     # Lógica de interação com a página
│── README.md     # Documentação do projeto
```

## 💡 Próximos passos
- Adicionar mais operações (subtração, multiplicação, divisão).
- Melhorar o layout com CSS.
- Criar testes unitários em JavaScript.
